#include <memory.h>
#include "lost.h"
 
void bzero(void *s, int n){
	memset(s, 0, n);
}